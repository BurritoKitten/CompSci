public class SoccerTeam {
  private int wins;
  private int losses;
  private int ties;
  private int teamNum;
  private static int totalGames = 0;
  private static int totalGoals = 0;
  private static int totalTeams = 0;

  public SoccerTeam() {
    this.reset();
    totalTeams++;
    teamNum = totalTeams;
  }

  public void played(SoccerTeam that, int thisScore, int thatScore) {
    if (thisScore > thatScore) {
      this.wins++;
      that.losses++;
    } else if (thisScore < thatScore) {
      this.losses++;
      that.wins++;
    } else if (thisScore == thatScore) {
      this.ties++;
      that.ties++;
    }
    totalGames++;
    totalGoals += thisScore + thatScore;
  }

  public int getPoints() {
    return 3 * wins + 1 * ties;
  }

  public void reset() {
    wins = 0;
    losses = 0;
    ties = 0;
  }

  public static int getTotalGames() {
    return totalGames;
  }

  public static int getTotalGoals() {
    return totalGoals;
  }

  public static void startTournament() {
    totalGames = 0;
    totalGoals = 0;
  }

  public String toString() {
    return "Team "+teamNum+":\nWins: "+wins+"\nLoss: "+losses+"\nTies: "+ties+"\nPoints: "+this.getPoints()+"\n";
  }

  public static void main(String args[]) {
    SoccerTeam team1 = new SoccerTeam();
    SoccerTeam team2 = new SoccerTeam();
    SoccerTeam team3 = new SoccerTeam();
    SoccerTeam team4 = new SoccerTeam();
    startTournament();
    team1.played(team4, 7, 3);
    team2.played(team3, 5, 6);
    team1.played(team3, 3, 2);
    team2.played(team4, 4, 4);
    System.out.println(team1);
    System.out.println(team2);
    System.out.println(team3);
    System.out.println(team4);
    startTournament();
    team1.reset();
    team2.reset();
    team3.reset();
    team4.reset();
    team1.played(team4, 2, 5);
    team2.played(team3, 6, 7);
    team3.played(team4, 2, 1);
    team2.played(team1, 10, 3);
    System.out.println(team1);
    System.out.println(team2);
    System.out.println(team3);
    System.out.println(team4);
  }
}

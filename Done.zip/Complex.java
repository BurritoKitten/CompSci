public class Complex {
  private double a_;
  private double b_;

  public Complex(double a, double b) {
    a_ = a;
    b_ = b;
  }

  public Complex(double a) {
    this(a, 0);
  }

  public Complex() {
    this(0);
  }

  public double abs() {
    return Math.sqrt(a_ * a_ + b_ * b_);
  }

  public void add(Complex other) {
    a_ += other.a_;
    b_ += other.b_;
  }

  public void add(double num) {
    this.add(new Complex(num, 0));
  }

  public void multiply(Complex other) {
    double a = (a_ * other.a_ - b_ * other.b_);
    double b = (a_ * other.b_ + b_ * other.a_);
    a_ = a;
    b_ = b;
  }

  public void multiply(double num) {
    this.multiply(new Complex(num, 0));
  }

  public String toString() {
    return a_ + " " + b_ + "i";
  }

  public static void main(String[] args) {
    Complex num1 = new Complex(1);
    Complex num2 = new Complex(3, 5);
    Complex num3 = new Complex(0, 5);
    Complex num4 = new Complex(7, 9);
    Complex num5 = new Complex(1, 2);
    Complex num6 = new Complex(5);
    System.out.println(num1);
    System.out.println(num2);
    System.out.println(num3);
    System.out.println(num4);
    System.out.println(num5);
    System.out.println(num6);
    System.out.println();
    System.out.println(num1.abs());
    System.out.println(num2.abs());
    System.out.println(num3.abs());
    System.out.println(num4.abs());
    System.out.println(num5.abs());
    System.out.println(num6.abs());
    System.out.println();
    num1.add(num2);
    num2.add(1);
    num1.add(num4);
    num6.multiply(num4);
    num6.multiply(num5);
    num2.multiply(num2);
    num3.add(num3);
    System.out.println(num1);
    System.out.println(num2);
    System.out.println(num3);
    System.out.println(num4);
    System.out.println(num5);
    System.out.println(num6);
  }
}

public class WhileLoops 
{
    public int addOdds(int num)
    {
        int i = 1;
        int t = 0;
        while (i <= num)
        {
            if (i%2 == 1){t+=i;}
            i++;
        }
        return t;
    }

    public int sumDigits(int num)
    {
        int total = 0;
        while (num > 0)
        {
            total += num%10;
            num /= 10;
        }
        return total;
    }

    public int howManyYears(double start, double end)
    {
        int year = 0;
        while (start < end)
        {
            start *= 1.0113;
            year ++;
        }
        return year;
    }

    public void printSum(int num)
    {
        int i = 2;
        System.out.print(1);
        while (i <= num)
        {
            System.out.print(" + "+i);
            i++;
        }
        System.out.println(" = "+(num+1)*num/2);
    }

    public boolean isPerfectSquare(int num)
    {
        int i = 1;
        while (num > 0)
        {
            num -= i;
            i += 2;
        }
        return num == 0;
    }

    public static void main(String[] args)
    {
        WhileLoops inst = new WhileLoops();
        System.out.println(inst.addOdds(8));
        System.out.println(inst.sumDigits(1234));
        System.out.println(inst.howManyYears(120, 150));
        inst.printSum(9);
        System.out.println(inst.isPerfectSquare(49));
        System.out.println(inst.isPerfectSquare(50));
    }
}
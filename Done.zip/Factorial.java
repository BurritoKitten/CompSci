public class Factorial {
    public long calcFactorial(int num)
    {
        long total = 1;
        for(int i=2; i<=num; i++){total*=i;}
        return total;
    }

    public double calcE()
    {
        int dec = 100; //round to 'dec' decimal place
        double num = 1;
        double e = 1;
        double round = Math.pow(10, -dec);
        for (int i=1; num>=round; i++)
        {
            num=1.0/calcFactorial(i);
            e+=num;
        }
        return e;//(int)(e/round)*round;
    }
    public double calcEX(int x)
    {
        int dec = 3; //round to 'dec' decimal place
        double num = 1;
        double e = 1;
        double round = Math.pow(10, -dec);
        for (int i=1; num>=round; i++)
        {
            num=Math.pow(x, i)/calcFactorial(i);
            e+=num;
        }
        return (long)(e/round)*round;
    }

    public static void main(String[] args)
    {
        Factorial inst = new Factorial();
        for(int i=1; i<=20; i++){System.out.println("cF"+i+": "+inst.calcFactorial(i));}
        System.out.println("E: "+inst.calcE());
        for(int i=1; i<=5; i++){System.out.println("eX"+i+": "+inst.calcEX(i));}
    }
}
using System;

namespace Sharp
{
    class Sharp
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}